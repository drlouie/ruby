#!/usr/bin/env ruby

#- Load the Whois class
require 'whois'

#- Take note of the time we start processing this user request
startProcess = Time.now

#- Define the whoisQuery method
def whoisQuery(domain)

	#- Begin routine
	begin
		#- Attempt 
		r = Whois.whois(domain)
	#- Failsafe triggered
	rescue 
		#- Silence: Nothing to do
	#- End routine
	end
	
	#- Connection was successful, port was open
	if r
		#- Let user know port was open
		# puts r
	#- End connection state routine
	end
	
	#- return domain as callback, required by test_domain, our test unit
	return domain
	
#- End whoisQuery method
end