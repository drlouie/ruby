#!/usr/bin/env ruby

require 'test/unit'
require_relative 'whois-query'

#- Initialize the TestAdd class using Test::Unit::TestCase
class TestAdd < Test::Unit::TestCase
	#- Define a test method named test_domain
    def test_domain
    	expected = whoisQuery('google.com')
    	assert_equal expected, 'google.com'
    end
end